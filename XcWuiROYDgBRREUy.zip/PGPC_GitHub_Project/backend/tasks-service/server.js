require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");

const app = express();
app.use(express.json());

const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
};

async function getConnection() {
  return await mysql.createConnection(dbConfig);
}

// Get tasks for a project
app.get("/api/projects/:projectId/tasks", async (req, res) => {
  const { projectId } = req.params;
  try {
    const connection = await getConnection();
    const [rows] = await connection.execute(
      "SELECT * FROM tasks WHERE project_id = ?",
      [projectId]
    );
    connection.end();
    res.json({ tasks: rows });
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});

// Create a new task
app.post("/api/projects/:projectId/tasks", async (req, res) => {
  const { projectId } = req.params;
  const { title, description, assignedTo, status } = req.body;
  try {
    const connection = await getConnection();
    const [result] = await connection.execute(
      "INSERT INTO tasks (project_id, title, description, assigned_to, status) VALUES (?, ?, ?, ?, ?)",
      [projectId, title, description, assignedTo, status]
    );
    connection.end();
    res.status(201).json({ id: result.insertId, projectId, title, description, assignedTo, status });
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});

const PORT = process.env.PORT || 3003;
app.listen(PORT, () => console.log(`Tasks Service running on port ${PORT}`));

