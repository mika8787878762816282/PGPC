require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");

const app = express();
app.use(express.json());

const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
};

async function getConnection() {
  return await mysql.createConnection(dbConfig);
}

// Get all projects
app.get("/api/projects", async (req, res) => {
  try {
    const connection = await getConnection();
    const [rows] = await connection.execute("SELECT * FROM projects");
    connection.end();
    res.json({ projects: rows });
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});

// Create a new project
app.post("/api/projects", async (req, res) => {
  const { name, description, userId } = req.body; // userId from authenticated user
  try {
    const connection = await getConnection();
    const [result] = await connection.execute(
      "INSERT INTO projects (name, description, created_by) VALUES (?, ?, ?)",
      [name, description, userId]
    );
    connection.end();
    res.status(201).json({ id: result.insertId, name, description, created_by: userId });
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`Projects Service running on port ${PORT}`));

