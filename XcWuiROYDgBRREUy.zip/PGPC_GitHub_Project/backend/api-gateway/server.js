require('dotenv').config();
const express = require('express');
const proxy = require('express-http-proxy');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) return res.sendStatus(401); // No token

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403); // Invalid token
    req.user = user;
    next();
  });
};

// Public routes (Auth Service)
app.use('/api/auth', proxy(process.env.AUTH_SERVICE_URL));

// Protected routes (Projects and Tasks Services)
app.use('/api/projects', authenticateToken, proxy(process.env.PROJECTS_SERVICE_URL));
app.use('/api/tasks', authenticateToken, proxy(process.env.TASKS_SERVICE_URL));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API Gateway running on port ${PORT}`));

