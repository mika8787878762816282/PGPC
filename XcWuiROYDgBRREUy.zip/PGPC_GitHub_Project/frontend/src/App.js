import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [message, setMessage] = useState('');
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    // Exemple d'appel à un microservice backend
    fetch('/api/projects')
      .then(response => response.json())
      .then(data => {
        if (data.message) {
          setMessage(data.message);
        } else if (data.projects) {
          setProjects(data.projects);
        }
      })
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Plateforme de Gestion de Projets Collaborative</h1>
        <p>{message || 'Bienvenue sur la PGPC !'}</p>
        <h2>Vos Projets</h2>
        {projects.length > 0 ? (
          <ul>
            {projects.map(project => (
              <li key={project.id}>{project.name}</li>
            ))}
          </ul>
        ) : (
          <p>Aucun projet trouvé. Créez-en un !</p>
        )}
      </header>
    </div>
  );
}

export default App;

